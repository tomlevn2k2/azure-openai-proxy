import json
import logging
import os
import secrets
import time
import uuid
from typing import Any

import httpx
from azure.identity import ManagedIdentityCredential
from azure.monitor.opentelemetry import configure_azure_monitor
from fastapi import FastAPI, Header, HTTPException, Request, Response
from fastapi.exception_handlers import (
    http_exception_handler as fastapi_default_http_exception_handler,
)
from fastapi.responses import StreamingResponse
from opentelemetry import metrics, trace
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
from opentelemetry.propagate import extract
from opentelemetry.sdk.resources import Resource
from opentelemetry.trace import SpanKind
from starlette.background import BackgroundTask
from starlette.datastructures import MutableHeaders
from starlette.exceptions import HTTPException as StarletteHTTPException

from flux import proxy_flux_edit, proxy_flux_generation
from util import (
    build_azure_url,
    build_response_headers,
    format_body_for_log,
    redact_headers,
    rewrite_payload_for_azure,
    set_log_body_limit,
)

app = FastAPI()

AZURE_OPENAI_BASE_URL = os.getenv("AZURE_OPENAI_BASE_URL", "").rstrip("/")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "preview")
AZURE_CLIENT_ID = os.getenv("AZURE_CLIENT_ID")
PROXY_API_KEY = os.getenv("PROXY_API_KEY")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
LOG_BODY_LIMIT = int(os.getenv("LOG_BODY_LIMIT", "20000"))

APP_INSIGHTS_CONNECTION_STRING = os.getenv("APP_INSIGHTS_CONNECTION_STRING", "").strip()
OTEL_SERVICE_NAME = os.getenv("OTEL_SERVICE_NAME", "azure-openai-proxy")

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.CRITICAL + 1),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)

logger = logging.getLogger("azure_openai_proxy")
logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))
logger.propagate = True
set_log_body_limit(LOG_BODY_LIMIT)

if not AZURE_OPENAI_BASE_URL:
    raise RuntimeError(
        "AZURE_OPENAI_BASE_URL is required, e.g. https://<resource>.openai.azure.com"
    )

credential = (
    ManagedIdentityCredential(client_id=AZURE_CLIENT_ID)
    if AZURE_CLIENT_ID
    else ManagedIdentityCredential()
)

TOKEN_SCOPE = "https://cognitiveservices.azure.com/.default"
TIMEOUT = httpx.Timeout(connect=10.0, read=600.0, write=600.0, pool=10.0)


def configure_app_insights() -> bool:
    if not APP_INSIGHTS_CONNECTION_STRING:
        logger.info(
            "Application Insights disabled because APP_INSIGHTS_CONNECTION_STRING is not set"
        )
        return False

    configure_azure_monitor(
        connection_string=APP_INSIGHTS_CONNECTION_STRING,
        logger_name=logger.name,
        resource=Resource.create({"service.name": OTEL_SERVICE_NAME}),
    )

    HTTPXClientInstrumentor().instrument()

    logger.info(
        "Application Insights enabled service_name=%s",
        OTEL_SERVICE_NAME,
    )
    return True


APP_INSIGHTS_ENABLED = configure_app_insights()

tracer = trace.get_tracer(OTEL_SERVICE_NAME)
meter = metrics.get_meter(OTEL_SERVICE_NAME)

route_duration_histogram = meter.create_histogram(
    name="proxy.route.duration",
    unit="ms",
    description="End-to-end response time for each FastAPI route",
)


def record_route_response_time(
    route: str,
    method: str,
    status_code: int,
    duration_ms: float,
) -> None:
    route_duration_histogram.record(
        duration_ms,
        attributes={
            "http.route": route or "<unknown>",
            "http.method": method,
            "http.status_code": status_code,
        },
    )


def _decode_asgi_headers(raw_headers: list[tuple[bytes, bytes]]) -> dict[str, str]:
    return {
        k.decode("latin-1"): v.decode("latin-1", errors="replace")
        for k, v in raw_headers
    }


def _route_from_scope(scope: dict[str, Any]) -> str:
    route = scope.get("route")
    route_path = getattr(route, "path", None)
    return route_path or scope.get("path", "<unknown>")


def _current_trace_context() -> dict[str, str | None]:
    span = trace.get_current_span()
    if not span:
        return {"trace_id": None, "span_id": None}

    ctx = span.get_span_context()
    if not ctx or ctx.trace_id == 0 or ctx.span_id == 0:
        return {"trace_id": None, "span_id": None}

    return {
        "trace_id": f"{ctx.trace_id:032x}",
        "span_id": f"{ctx.span_id:016x}",
    }


class AppInsightsRequestResponseMiddleware:
    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        started = time.perf_counter()
        request_id = str(uuid.uuid4())

        method = scope.get("method", "")
        path = scope.get("path", "")
        scheme = scope.get("scheme", "http")
        client_addr = scope.get("client")
        request_headers = redact_headers(_decode_asgi_headers(scope.get("headers", [])))

        request_body = bytearray()
        response_body = bytearray()
        response_headers: dict[str, str] = {}
        response_status = 500
        error_text: str | None = None

        parent_context = extract(request_headers)

        async def receive_wrapper():
            message = await receive()
            if message["type"] == "http.request":
                chunk = message.get("body", b"")
                if chunk and len(request_body) < LOG_BODY_LIMIT:
                    remaining = LOG_BODY_LIMIT - len(request_body)
                    request_body.extend(chunk[:remaining])
            return message

        async def send_wrapper(message):
            nonlocal response_status, response_headers

            if message["type"] == "http.response.start":
                raw_headers = message.setdefault("headers", [])
                headers = MutableHeaders(raw=raw_headers)

                if "x-correlation-id" not in headers:
                    headers.append("x-correlation-id", request_id)

                response_status = message["status"]
                response_headers = redact_headers(_decode_asgi_headers(raw_headers))

            elif message["type"] == "http.response.body":
                chunk = message.get("body", b"")
                if chunk and len(response_body) < LOG_BODY_LIMIT:
                    remaining = LOG_BODY_LIMIT - len(response_body)
                    response_body.extend(chunk[:remaining])

            await send(message)

        with tracer.start_as_current_span(
            name=f"{method} {path}",
            context=parent_context,
            kind=SpanKind.SERVER,
        ) as span:
            span.set_attribute("http.method", method)
            span.set_attribute("url.path", path)
            span.set_attribute("url.scheme", scheme)
            span.set_attribute("proxy.request_id", request_id)

            if client_addr:
                span.set_attribute("client.address", str(client_addr[0]))
                if len(client_addr) > 1:
                    span.set_attribute("client.port", int(client_addr[1]))

            try:
                await self.app(scope, receive_wrapper, send_wrapper)
            except Exception as exc:
                error_text = str(exc)
                span.record_exception(exc)
                raise
            finally:
                duration_ms = round((time.perf_counter() - started) * 1000, 3)
                route = _route_from_scope(scope)

                if route:
                    span.set_attribute("http.route", route)
                    span.update_name(f"{method} {route}")

                span.set_attribute("http.status_code", response_status)
                span.set_attribute("proxy.duration_ms", duration_ms)

                record_route_response_time(
                    route=route,
                    method=method,
                    status_code=response_status,
                    duration_ms=duration_ms,
                )

                correlation = {
                    "request_id": request_id,
                    "route": route,
                    "method": method,
                    "path": path,
                    "status_code": response_status,
                    "duration_ms": duration_ms,
                    **_current_trace_context(),
                }

                logger.info(
                    "appinsights.http.request %s",
                    json.dumps(
                        {
                            **correlation,
                            "headers": request_headers,
                            "body": format_body_for_log(bytes(request_body)),
                        },
                        ensure_ascii=False,
                    ),
                )

                logger.info(
                    "appinsights.http.response %s",
                    json.dumps(
                        {
                            **correlation,
                            "headers": response_headers,
                            "body": format_body_for_log(bytes(response_body)),
                            "error": error_text,
                        },
                        ensure_ascii=False,
                    ),
                )


app.add_middleware(AppInsightsRequestResponseMiddleware)


@app.on_event("startup")
async def log_startup_config() -> None:
    logger.info(
        "Startup config azure_base_url=%s api_version=%s log_level=%s log_body_limit=%s managed_identity_client_id=%s app_insights_enabled=%s",
        AZURE_OPENAI_BASE_URL,
        AZURE_OPENAI_API_VERSION,
        LOG_LEVEL,
        LOG_BODY_LIMIT,
        AZURE_CLIENT_ID or "<system-assigned>",
        APP_INSIGHTS_ENABLED,
    )


@app.exception_handler(HTTPException)
async def fastapi_http_exception_handler(
    request: Request,
    exc: HTTPException,
) -> Response:
    logger.warning(
        "HTTPException method=%s path=%s status=%s detail=%s",
        request.method,
        request.url.path,
        exc.status_code,
        json.dumps(exc.detail, ensure_ascii=False)
        if not isinstance(exc.detail, str)
        else exc.detail,
    )
    return await fastapi_default_http_exception_handler(request, exc)


@app.exception_handler(StarletteHTTPException)
async def starlette_http_exception_handler(
    request: Request,
    exc: StarletteHTTPException,
) -> Response:
    logger.warning(
        "StarletteHTTPException method=%s path=%s status=%s detail=%s",
        request.method,
        request.url.path,
        exc.status_code,
        json.dumps(exc.detail, ensure_ascii=False)
        if not isinstance(exc.detail, str)
        else exc.detail,
    )
    return await fastapi_default_http_exception_handler(request, exc)


@app.exception_handler(Exception)
async def unhandled_exception_handler(
    request: Request,
    exc: Exception,
) -> Response:
    logger.exception(
        "Unhandled exception method=%s path=%s error=%s",
        request.method,
        request.url.path,
        str(exc),
    )
    raise exc


def get_bearer_token() -> str:
    token = credential.get_token(TOKEN_SCOPE)
    return token.token


def validate_incoming_bearer(authorization: str | None) -> None:
    if not PROXY_API_KEY:
        return
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing Authorization header")
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(status_code=401, detail="Invalid Authorization header")
    if not secrets.compare_digest(token, PROXY_API_KEY):
        raise HTTPException(status_code=401, detail="Invalid API key")


async def cleanup_stream(upstream: httpx.Response, client: httpx.AsyncClient) -> None:
    await upstream.aclose()
    await client.aclose()


async def proxy_json_post(
    request: Request,
    authorization: str | None,
    upstream_path: str,
) -> Response:
    validate_incoming_bearer(authorization)

    try:
        raw_body = await request.body()
    except Exception:
        logger.exception("Failed to read request body")
        raise HTTPException(status_code=400, detail="Unable to read request body")

    logger.info(
        "Incoming request method=%s path=%s headers=%s body=%s",
        request.method,
        request.url.path,
        json.dumps(redact_headers(dict(request.headers)), ensure_ascii=False),
        format_body_for_log(raw_body),
    )

    try:
        payload = json.loads(raw_body)
    except Exception:
        logger.error(
            "Invalid JSON body method=%s path=%s",
            request.method,
            request.url.path,
        )
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Request JSON must be an object")

    model = payload.get("model")
    if not model or not isinstance(model, str):
        raise HTTPException(
            status_code=400,
            detail="Request JSON must include string field 'model'",
        )

    payload = rewrite_payload_for_azure(payload, upstream_path)

    azure_url = build_azure_url(
        AZURE_OPENAI_BASE_URL,
        AZURE_OPENAI_API_VERSION,
        upstream_path,
    )

    bearer_token = get_bearer_token()
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "Content-Type": "application/json",
    }

    client = httpx.AsyncClient(timeout=TIMEOUT)

    try:
        upstream_request = client.build_request(
            "POST",
            azure_url,
            json=payload,
            headers=headers,
        )
        logger.info(
            "Outgoing upstream request method=%s url=%s headers=%s body=%s",
            upstream_request.method,
            str(upstream_request.url),
            json.dumps(
                redact_headers(dict(upstream_request.headers)), ensure_ascii=False
            ),
            format_body_for_log(upstream_request.content or b""),
        )
        upstream = await client.send(
            upstream_request,
            stream=payload.get("stream") is True,
        )
    except httpx.HTTPError as e:
        logger.exception(
            "Upstream request failed method=%s path=%s upstream_path=%s error=%s",
            request.method,
            request.url.path,
            upstream_path,
            str(e),
        )
        await client.aclose()
        raise HTTPException(status_code=502, detail=f"Upstream request failed: {e}")

    content_type = upstream.headers.get("content-type", "application/json")
    response_headers = build_response_headers(dict(upstream.headers))

    if payload.get("stream") is True:
        if upstream.status_code >= 400:
            body = await upstream.aread()
            logger.error(
                "Upstream error method=%s path=%s upstream_path=%s status=%s body=%s",
                request.method,
                request.url.path,
                upstream_path,
                upstream.status_code,
                format_body_for_log(body),
            )
            await upstream.aclose()
            await client.aclose()
            return Response(
                content=body,
                status_code=upstream.status_code,
                headers=response_headers,
                media_type=content_type,
            )

        return StreamingResponse(
            upstream.aiter_raw(),
            status_code=upstream.status_code,
            headers=response_headers,
            media_type=content_type,
            background=BackgroundTask(cleanup_stream, upstream, client),
        )

    body = await upstream.aread()

    if upstream.status_code >= 400:
        logger.error(
            "Upstream error method=%s path=%s upstream_path=%s status=%s body=%s",
            request.method,
            request.url.path,
            upstream_path,
            upstream.status_code,
            format_body_for_log(body),
        )

    await upstream.aclose()
    await client.aclose()

    return Response(
        content=body,
        status_code=upstream.status_code,
        headers=response_headers,
        media_type=content_type,
    )


@app.get("/v1/models")
async def models(
    request: Request,
    authorization: str | None = Header(default=None),
) -> Response:
    validate_incoming_bearer(authorization)

    azure_url = build_azure_url(
        AZURE_OPENAI_BASE_URL,
        AZURE_OPENAI_API_VERSION,
        "models",
    )

    headers = {
        "Authorization": f"Bearer {get_bearer_token()}",
    }

    client = httpx.AsyncClient(timeout=TIMEOUT)

    try:
        upstream_request = client.build_request(
            "GET",
            azure_url,
            headers=headers,
            params=dict(request.query_params),
        )
        upstream = await client.send(upstream_request, stream=False)
    except httpx.HTTPError as e:
        await client.aclose()
        raise HTTPException(status_code=502, detail=f"Upstream request failed: {e}")

    content_type = upstream.headers.get("content-type", "application/json")
    response_headers = build_response_headers(dict(upstream.headers))
    body = await upstream.aread()

    await upstream.aclose()
    await client.aclose()

    return Response(
        content=body,
        status_code=upstream.status_code,
        headers=response_headers,
        media_type=content_type,
    )


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/v1/responses")
async def responses(
    request: Request,
    authorization: str | None = Header(default=None),
) -> Response:
    return await proxy_json_post(request, authorization, "responses")


@app.post("/v1/chat/completions")
async def chat_completions(
    request: Request,
    authorization: str | None = Header(default=None),
) -> Response:
    return await proxy_json_post(request, authorization, "chat/completions")


@app.post("/v1/embeddings")
async def embeddings(
    request: Request,
    authorization: str | None = Header(default=None),
) -> Response:
    return await proxy_json_post(request, authorization, "embeddings")


@app.post("/v1/images/generations")
async def image_generations(
    request: Request,
    authorization: str | None = Header(default=None),
) -> Response:
    return await proxy_json_post(request, authorization, "images/generations")


@app.post("/flux/images/generations")
async def flux_image_generations(
    request: Request,
    authorization: str | None = Header(default=None),
) -> Response:
    validate_incoming_bearer(authorization)
    return await proxy_flux_generation(
        request=request,
        bearer_token=get_bearer_token(),
        azure_openai_base_url=AZURE_OPENAI_BASE_URL,
        api_version=AZURE_OPENAI_API_VERSION,
        timeout=TIMEOUT,
    )


@app.post("/flux/images/edit")
@app.post("/flux/images/edits")
async def flux_image_edit(
    request: Request,
    authorization: str | None = Header(default=None),
) -> Response:
    validate_incoming_bearer(authorization)
    return await proxy_flux_edit(
        request=request,
        bearer_token=get_bearer_token(),
        azure_openai_base_url=AZURE_OPENAI_BASE_URL,
        api_version=AZURE_OPENAI_API_VERSION,
        timeout=TIMEOUT,
    )
