import json
import logging
from typing import Any

LOG_BODY_LIMIT = 20000

EXCLUDED_RESPONSE_HEADERS = {
    "content-encoding",
    "transfer-encoding",
    "connection",
    "keep-alive",
    "content-length",
    "content-type",
}

SENSITIVE_HEADERS = {
    "authorization",
    "proxy-authorization",
    "api-key",
    "x-api-key",
    "cookie",
    "set-cookie",
}

SENSITIVE_JSON_KEYS = {
    "api_key",
    "apikey",
    "authorization",
    "token",
    "access_token",
    "refresh_token",
    "password",
    "secret",
    "client_secret",
}

logger = logging.getLogger("azure_openai_proxy")


def set_log_body_limit(limit: int) -> None:
    global LOG_BODY_LIMIT
    LOG_BODY_LIMIT = limit


def truncate_for_log(text: str) -> str:
    if len(text) <= LOG_BODY_LIMIT:
        return text
    remaining = len(text) - LOG_BODY_LIMIT
    return f"{text[:LOG_BODY_LIMIT]} ... [truncated {remaining} chars]"


def redact_headers(headers: dict[str, str]) -> dict[str, str]:
    return {
        k: ("***REDACTED***" if k.lower() in SENSITIVE_HEADERS else v)
        for k, v in headers.items()
    }


def redact_json(value: Any) -> Any:
    if isinstance(value, dict):
        output = {}
        for k, v in value.items():
            if k.lower() in SENSITIVE_JSON_KEYS:
                output[k] = "***REDACTED***"
            else:
                output[k] = redact_json(v)
        return output
    if isinstance(value, list):
        return [redact_json(v) for v in value]
    return value


def format_json_obj_for_log(value: Any) -> str:
    return truncate_for_log(json.dumps(redact_json(value), ensure_ascii=False))


def format_body_for_log(body: bytes) -> str:
    text = body.decode("utf-8", errors="replace")
    try:
        parsed = json.loads(text)
        safe = redact_json(parsed)
        return truncate_for_log(json.dumps(safe, ensure_ascii=False))
    except Exception:
        return truncate_for_log(text)


def rewrite_payload_for_azure(
    payload: dict[str, Any],
    upstream_path: str,
) -> dict[str, Any]:
    rewritten = dict(payload)
    model = rewritten.get("model")
    if upstream_path == "chat/completions" and isinstance(model, str):
        if model.startswith("gpt-5"):
            if "max_tokens" in rewritten and "max_completion_tokens" not in rewritten:
                original_value = rewritten.pop("max_tokens")
                try:
                    rewritten["max_completion_tokens"] = max(int(original_value), 1000)
                except (TypeError, ValueError):
                    rewritten["max_completion_tokens"] = original_value
                logger.info(
                    "Rewrote outgoing payload for model=%s: max_tokens=%r -> max_completion_tokens=%r",
                    model,
                    original_value,
                    rewritten["max_completion_tokens"],
                )
    return rewritten


def build_azure_url(base_url: str, api_version: str, path: str) -> str:
    base = f"{base_url.rstrip('/')}/openai/v1/{path.lstrip('/')}"
    if api_version:
        return f"{base}?api-version={api_version}"
    return base


def build_response_headers(upstream_headers: dict[str, str]) -> dict[str, str]:
    return {
        k: v
        for k, v in upstream_headers.items()
        if k.lower() not in EXCLUDED_RESPONSE_HEADERS
    }
