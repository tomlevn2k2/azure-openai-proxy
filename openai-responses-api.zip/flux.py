import base64
import json
import logging
import re
from collections.abc import Iterable
from typing import Any
from urllib.parse import urlparse

import httpx
from fastapi import HTTPException, Request, Response
from starlette.datastructures import UploadFile

from util import build_response_headers, format_body_for_log, redact_headers

logger = logging.getLogger("azure_openai_proxy")

DEFAULT_FLUX_GENERATION_MODEL_PATH = "flux-2-pro"
DEFAULT_FLUX_EDIT_MODEL_PATH = "flux-2-pro"

FLUX_EDIT_IMAGE_LIMITS = {
    "flux-2-flex": 10,
    "flux-2-pro": 8,
    "flux-kontext-pro": 1,
}

FLUX_MODEL_PATH_ALIASES = {
    "flux-2-pro": "flux-2-pro",
    "flux.2-pro": "flux-2-pro",
    "flux-2-flex": "flux-2-flex",
    "flux.2-flex": "flux-2-flex",
    "flux-kontext-pro": "flux-kontext-pro",
    "flux.1-kontext-pro": "flux-kontext-pro",
    "flux-1-kontext-pro": "flux-kontext-pro",
    "flux-pro-1.1": "flux-pro-1.1",
    "flux-1.1-pro": "flux-pro-1.1",
    "flux1.1-pro": "flux-pro-1.1",
}

FLUX_ALLOWED_JSON_FIELDS = {
    "aspect_ratio",
    "guidance",
    "height",
    "input_image",
    "input_image_2",
    "input_image_3",
    "input_image_4",
    "input_image_5",
    "input_image_6",
    "input_image_7",
    "input_image_8",
    "input_image_9",
    "input_image_10",
    "model",
    "n",
    "output_format",
    "prompt",
    "prompt_upsampling",
    "safety_tolerance",
    "seed",
    "steps",
    "width",
}

FORM_INT_FIELDS = {"height", "n", "safety_tolerance", "seed", "steps", "width"}
FORM_FLOAT_FIELDS = {"guidance"}
FORM_TRUE_VALUES = {"1", "on", "true", "yes"}
FORM_FALSE_VALUES = {"0", "false", "no", "off"}
IMAGE_FIELD_PATTERN = re.compile(r"^image(?:\[\]|\[\d+\]|[._]\d+)?$")


def _normalize_model_path(model_path: str) -> str:
    normalized = model_path.strip().strip("/")
    prefix = "providers/blackforestlabs/v1/"
    if normalized.startswith(prefix):
        return normalized[len(prefix) :]
    return normalized


def resolve_flux_model_path(model: str, default_model_path: str) -> str:
    normalized = _normalize_model_path(model).lower()
    if not normalized:
        raise HTTPException(status_code=400, detail="Request model must not be empty")
    return FLUX_MODEL_PATH_ALIASES.get(normalized, default_model_path)


def extract_resource_name(base_url: str) -> str:
    parsed = urlparse(base_url)
    host = (parsed.hostname or "").strip().lower()
    if not host:
        raise ValueError("AZURE_OPENAI_BASE_URL must include a hostname")

    for suffix in (
        ".services.ai.azure.com",
        ".openai.azure.com",
        ".api.cognitive.microsoft.com",
    ):
        if host.endswith(suffix):
            resource = host[: -len(suffix)]
            if resource:
                return resource

    first_label = host.split(".", 1)[0]
    if not first_label:
        raise ValueError("Unable to extract Azure resource name from base URL")
    return first_label


def build_flux_endpoint(
    azure_openai_base_url: str,
    api_version: str,
    model_path: str,
) -> str:
    parsed = urlparse(azure_openai_base_url)
    resource = extract_resource_name(azure_openai_base_url)
    scheme = parsed.scheme or "https"
    normalized_path = _normalize_model_path(model_path)
    return (
        f"{scheme}://{resource}.services.ai.azure.com/"
        f"providers/blackforestlabs/v1/{normalized_path}?api-version={api_version}"
    )


def _parse_size(size: Any) -> tuple[int, int]:
    if not isinstance(size, str):
        raise HTTPException(
            status_code=400,
            detail="Request field 'size' must be a string like '1024x1024'",
        )

    width_text, separator, height_text = size.lower().partition("x")
    if not separator:
        raise HTTPException(
            status_code=400,
            detail="Request field 'size' must be a string like '1024x1024'",
        )

    try:
        width = int(width_text)
        height = int(height_text)
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail="Request field 'size' must be a string like '1024x1024'",
        ) from exc

    if width <= 0 or height <= 0:
        raise HTTPException(
            status_code=400,
            detail="Request field 'size' must contain positive dimensions",
        )

    return width, height


def _coerce_int(field_name: str, value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Field '{field_name}' must be an integer",
        ) from exc


def _coerce_float(field_name: str, value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Field '{field_name}' must be a number",
        ) from exc


def _coerce_form_value(field_name: str, value: str) -> Any:
    if field_name in FORM_INT_FIELDS:
        return _coerce_int(field_name, value)
    if field_name in FORM_FLOAT_FIELDS:
        return _coerce_float(field_name, value)
    if field_name in {"prompt_upsampling", "transparent", "transparent_background"}:
        lowered = value.strip().lower()
        if lowered in FORM_TRUE_VALUES:
            return True
        if lowered in FORM_FALSE_VALUES:
            return False
        raise HTTPException(
            status_code=400,
            detail=f"Field '{field_name}' must be a boolean",
        )
    return value


def _rewrite_generation_payload(payload: dict[str, Any]) -> dict[str, Any]:
    model = payload.get("model")
    if not isinstance(model, str) or not model.strip():
        raise HTTPException(
            status_code=400,
            detail="Request JSON must include string field 'model'",
        )

    prompt = payload.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        raise HTTPException(
            status_code=400,
            detail="Request JSON must include string field 'prompt'",
        )

    rewritten = {
        key: value for key, value in payload.items() if key in FLUX_ALLOWED_JSON_FIELDS
    }
    rewritten["model"] = model
    rewritten["prompt"] = prompt

    if "size" in payload and ("width" not in rewritten or "height" not in rewritten):
        width, height = _parse_size(payload["size"])
        rewritten["width"] = width
        rewritten["height"] = height

    if "n" in rewritten:
        rewritten["n"] = _coerce_int("n", rewritten["n"])
    else:
        rewritten["n"] = 1

    rewritten.setdefault("output_format", "png")

    if payload.get("background") == "transparent":
        rewritten.setdefault("output_format", "png")

    return rewritten


async def _collect_edit_images(request: Request) -> tuple[Any, list[UploadFile]]:
    try:
        form = await request.form()
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Invalid multipart form body") from exc

    uploads: list[UploadFile] = []
    for key, item in form.multi_items():
        if IMAGE_FIELD_PATTERN.fullmatch(key) and isinstance(item, UploadFile):
            uploads.append(item)

    return form, uploads


async def _encode_uploads_as_base64(uploads: Iterable[UploadFile]) -> list[str]:
    encoded: list[str] = []
    for upload in uploads:
        content = await upload.read()
        await upload.close()
        if not content:
            raise HTTPException(status_code=400, detail="Uploaded image file is empty")
        encoded.append(base64.b64encode(content).decode("ascii"))
    return encoded


async def _rewrite_edit_payload(
    request: Request,
    default_model_path: str,
) -> tuple[dict[str, Any], str]:
    form, uploads = await _collect_edit_images(request)

    model = form.get("model")
    if not isinstance(model, str) or not model.strip():
        raise HTTPException(
            status_code=400,
            detail="Multipart form must include string field 'model'",
        )

    prompt = form.get("prompt")
    if prompt is None:
        prompt = ""
    if not isinstance(prompt, str):
        raise HTTPException(
            status_code=400,
            detail="Multipart form field 'prompt' must be a string",
        )

    rewritten: dict[str, Any] = {
        "model": model,
        "prompt": prompt,
    }
    model_path = resolve_flux_model_path(model, default_model_path)

    for key in FLUX_ALLOWED_JSON_FIELDS:
        if key in {"model", "prompt"}:
            continue
        value = form.get(key)
        if isinstance(value, str) and value != "":
            rewritten[key] = _coerce_form_value(key, value)

    size = form.get("size")
    if isinstance(size, str) and size:
        width, height = _parse_size(size)
        rewritten["width"] = width
        rewritten["height"] = height

    rewritten.setdefault("output_format", "png")

    if form.get("background") == "transparent":
        rewritten.setdefault("output_format", "png")

    encoded_images = await _encode_uploads_as_base64(uploads)
    if not encoded_images:
        raise HTTPException(
            status_code=400,
            detail="Multipart form must include at least one uploaded image",
        )
    max_images = FLUX_EDIT_IMAGE_LIMITS.get(_normalize_model_path(model_path), 8)
    if len(encoded_images) > max_images:
        raise HTTPException(
            status_code=400,
            detail=f"Too many input images for {model_path}; maximum is {max_images}",
        )

    for index, image_data in enumerate(encoded_images):
        field_name = "input_image" if index == 0 else f"input_image_{index + 1}"
        rewritten[field_name] = image_data

    if "n" in rewritten:
        rewritten["n"] = _coerce_int("n", rewritten["n"])
    else:
        rewritten["n"] = 1

    return rewritten, model_path


async def _proxy_flux_request(
    request: Request,
    payload: dict[str, Any],
    upstream_url: str,
    bearer_token: str,
    timeout: httpx.Timeout,
) -> Response:
    headers = {
        "Authorization": f"Bearer {bearer_token}",
        "Content-Type": "application/json",
    }

    client = httpx.AsyncClient(timeout=timeout)
    try:
        upstream_request = client.build_request(
            "POST",
            upstream_url,
            json=payload,
            headers=headers,
        )
        logger.info(
            "Outgoing FLUX request method=%s path=%s url=%s headers=%s body=%s",
            request.method,
            request.url.path,
            str(upstream_request.url),
            json.dumps(redact_headers(dict(upstream_request.headers)), ensure_ascii=False),
            format_body_for_log(upstream_request.content or b""),
        )
        upstream = await client.send(upstream_request, stream=False)
    except httpx.HTTPError as exc:
        await client.aclose()
        raise HTTPException(
            status_code=502,
            detail=f"Upstream request failed: {exc}",
        ) from exc

    body = await upstream.aread()
    content_type = upstream.headers.get("content-type", "application/json")
    response_headers = build_response_headers(dict(upstream.headers))

    if upstream.status_code >= 400:
        logger.error(
            "FLUX upstream error method=%s path=%s status=%s body=%s",
            request.method,
            request.url.path,
            upstream.status_code,
            format_body_for_log(body),
        )

    await upstream.aclose()
    await client.aclose()

    return Response(
        content=body,
        status_code=upstream.status_code,
        headers=response_headers,
        media_type=content_type,
    )


async def proxy_flux_generation(
    request: Request,
    bearer_token: str,
    azure_openai_base_url: str,
    api_version: str,
    timeout: httpx.Timeout,
) -> Response:
    try:
        raw_body = await request.body()
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Unable to read request body") from exc

    logger.info(
        "Incoming FLUX generation request method=%s path=%s headers=%s body=%s",
        request.method,
        request.url.path,
        json.dumps(redact_headers(dict(request.headers)), ensure_ascii=False),
        format_body_for_log(raw_body),
    )

    try:
        payload = json.loads(raw_body)
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Invalid JSON body") from exc

    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Request JSON must be an object")

    rewritten = _rewrite_generation_payload(payload)
    model_path = resolve_flux_model_path(
        rewritten["model"],
        DEFAULT_FLUX_GENERATION_MODEL_PATH,
    )
    upstream_url = build_flux_endpoint(
        azure_openai_base_url,
        api_version,
        model_path,
    )
    return await _proxy_flux_request(
        request=request,
        payload=rewritten,
        upstream_url=upstream_url,
        bearer_token=bearer_token,
        timeout=timeout,
    )


async def proxy_flux_edit(
    request: Request,
    bearer_token: str,
    azure_openai_base_url: str,
    api_version: str,
    timeout: httpx.Timeout,
) -> Response:
    logger.info(
        "Incoming FLUX edit request method=%s path=%s headers=%s",
        request.method,
        request.url.path,
        json.dumps(redact_headers(dict(request.headers)), ensure_ascii=False),
    )

    rewritten, model_path = await _rewrite_edit_payload(
        request,
        DEFAULT_FLUX_EDIT_MODEL_PATH,
    )
    logger.info(
        "Rewritten FLUX edit request path=%s body=%s",
        request.url.path,
        format_body_for_log(json.dumps(rewritten, ensure_ascii=False).encode("utf-8")),
    )

    upstream_url = build_flux_endpoint(
        azure_openai_base_url,
        api_version,
        model_path,
    )
    return await _proxy_flux_request(
        request=request,
        payload=rewritten,
        upstream_url=upstream_url,
        bearer_token=bearer_token,
        timeout=timeout,
    )
